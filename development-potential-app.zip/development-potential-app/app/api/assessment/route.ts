import { NextResponse } from 'next/server'
import { buildAssessment } from '@/lib/assessment'
import type { SiteFormValues } from '@/lib/types'

export async function POST(request: Request) {
  const body = (await request.json()) as SiteFormValues
  return NextResponse.json(buildAssessment(body))
}
