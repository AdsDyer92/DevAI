import { NextResponse } from 'next/server'
import { buildAssessment } from '@/lib/assessment'
import type { SiteFormValues } from '@/lib/types'

export async function POST(request: Request) {
  const body = (await request.json()) as SiteFormValues
  const assessment = buildAssessment(body)
  const report = {
    title: 'Development appraisal summary',
    site: body.siteAddress,
    density: `${assessment.recommendedLowDensity}-${assessment.recommendedHighDensity} u/ha`,
    homes: assessment.targetUnits,
    height: assessment.headlineHeight,
    appraisal: assessment.appraisal,
  }

  return NextResponse.json(report)
}
